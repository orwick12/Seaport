import java.util.ArrayList;
import java.util.Scanner;


public class World extends Thing {
    ArrayList<Seaport> ports;
    PortTime time;

    //Constructor
    public World(Scanner sc) {
        super(sc);
        ports = new ArrayList<>();
    }

    //Accessors/Mutators:
    public ArrayList<Seaport> getPorts() {
        return ports;
    }

    public void setPorts(ArrayList<Seaport> p) {
        ports = p;
    }

    public PortTime getTime() {
        return time;
    }

    public void setTime(PortTime t) {
        time = t;
    }

    void process(String st) {
        System.out.println ("Processing >" + st + "<");
        Scanner sc = new Scanner(st);
        if (!sc.hasNext()) return;
        switch (sc.next()) {
            case "port":
                addPort(sc);
                break;
            case "dock":
                addDock(sc);
                break;
            case "pship":
                addPShip(sc);
                break;
            case "cship":
                addCShip(sc);
                break;
            case "person":
                addPerson(sc);
                break;
            case "job":
                addJob(sc);
                break;
            default:
                break;
            }
        }

    private void addPort(Scanner sc) {
        Seaport port = new Seaport(sc);
    }
    private void addDock(Scanner sc) {
        Dock dock = new Dock(sc);

    }
    private void addPShip(Scanner sc) {
        PassengerShip pShip = new PassengerShip(sc);
    }
    private void addCShip(Scanner sc) {
        CargoShip cShip = new CargoShip(sc);
    }
    private void addPerson(Scanner sc) {
        Person worker = new Person(sc);
    }
    private void addJob(Scanner sc) {
        Job skill = new Job(sc);
    }
    public void assignShip(Ship ms, Seaport msp, Dock md) {
        msp.getShips().add(ms);
        if(md != null){
            md.setShip(ms);
        }
        else{
            msp.getQueue().add(ms);
        }
    }

    public void assignPort(Seaport msp){
        ports.add(msp);
    }
    public void assignPerson(Person mp, Seaport msp){
        msp.getPersons().add(mp);
    }
    public void assignDock(Dock md, Seaport msp){
        msp.getDocks().add(md);
    }
    public void assignJob(Job mj, Thing parent){

    }

    public String toString(){
        String out = "\nWorld:\n\n";
        for (Seaport msp : ports) {
            out += msp;
        }
        return out;
    }
}